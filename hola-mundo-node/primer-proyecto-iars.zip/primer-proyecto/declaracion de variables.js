//Que es??
//Dclaracion de  variable

var variable =2; //Instacia
let variableLet =3;  //Local

var x = 2;
console.log(x)

x = 7;
console.log(x)

let z = 3;
console.log(z)

z = 7;
console.log(z)

var varible = "Soy una variable tipo VAR"

for(var i=0; i < 2; i++){
   let ejemplo = "Ejemplo LET" 
}

console.log(variable)