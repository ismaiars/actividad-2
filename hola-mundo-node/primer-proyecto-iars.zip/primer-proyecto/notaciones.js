// Notaciones

// ; --> Delimitar el final de una linea
// No siempre se requiere 
const a = 1; 
a;

// . --> accede a los atributos de un objeto
// Ejemplo
// alumno.edad;

// () --> Parentesis de funcion 
// agrega valores para la funcion
/*function promedio(a, b, c){
//todo el proceso de la funcion
}if(a>b){
//procesos
}
*/
// [] --> square brackets listas, arrays
// Ejemplo
// Declarar
const ar=[1,2,3,4];
// Acceder 
ar[2]
console.log(ar[2]);

// {} --> curly brackets
// objetos, funciones y estructuras
// Ejemplo
/*const alumno={
edad: 15,
estatura: 1.70,    
}

if(a>b){
//estructura de control
}

for(const x=1, 1=i, i++){
//estructura de control
}
*/