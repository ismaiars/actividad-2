//Datos primitivos
//Number
18;

//string
"Hola Mundo";
'Hola Mundo'

//Booleano
true;
false;

null;
undefined;